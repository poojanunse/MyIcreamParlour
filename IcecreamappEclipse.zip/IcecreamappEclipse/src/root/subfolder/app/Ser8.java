package root.subfolder.app;
import javax.servlet.*;
import java.io.*;
import java.sql.*;

public class Ser8 extends GenericServlet
{	
	public void service(ServletRequest req,ServletResponse res){	
		
		try{
			PrintWriter pw=	res.getWriter();
		ServletContext sc=getServletContext();
		String driver=sc.getInitParameter("driver");
		String url=sc.getInitParameter("url");
		String username=sc.getInitParameter("username");
		String password=sc.getInitParameter("password");
			
			Class.forName(driver);
			Connection con=DriverManager.getConnection(url,username,password);
		pw.println("Connected ..");
			
			pw.println("<style>");

	pw.println("body{");
	pw.println("background-image:url('back.jpg')");
	pw.println("}");

	pw.println("b{");
	pw.println("color:black");
	pw.println("}");

	pw.println("</style>");
	pw.println("<center>");
	pw.println("<h2><br><br><font color='blue'>Sign Up For New Users Only</font></h2>");
	pw.println("<form  action='reg'>");
	pw.println("<body >");
	pw.println("<table border='0' cellpadding='5' cellspacing='0' width='600'>");
	pw.println("<tr>");
	pw.println("<td><b>First, Last Name :</b></td>");
	pw.println("<td>");
	pw.println("<input id='FirstName' name='FirstName' type='text' maxlength='60' style='width:146px; border:1px solid #999999' />");
	pw.println("<input id='LastName' name='LastName' type='text' maxlength='60' style='width:146px; border:1px solid #999999' />");
	pw.println("</td>");
	pw.println("</tr>");
	pw.println("<tr>");
	pw.println("<td><b>Email address :</b></td>");
	pw.println("<td><input id='FromEmailAddress' name='FromEmailAddress' type='text' maxlength='60' style='width:300px; border:1px solid #999999' /></td>");
	pw.println("</tr><tr>");
	pw.println("<td><b>User name :</b></td>");
	pw.println("<td><input id='user' name='uname' type='text'>");
	pw.println("</tr>");
	pw.println("<tr><td><b>Password :</b></td>");
	pw.println("<td><input id='pwd_id' name='pswd' type='password'>");
	pw.println("</tr>");
	pw.println("<tr>");
	pw.println("<td><b>Cell Phone:</b></td>");
	pw.println("<td><input id='CellPhone' name='CellPhone' type='text' maxlength='43' style='width:250px; border:1px solid #999999' /></td>");
	pw.println("</tr>");
	pw.println("<tr>");
	pw.println("<td><b>Address :</b></td>");
	pw.println("<td><input id='StreetAddress1' name='StreetAddress1' type='text' maxlength='120' style='width:350px; border:1px solid #999999' /></td>");
	pw.println("</tr><tr>");
	pw.println("<td><b>City :</b></td>");
	pw.println("<td><input id='City' name='City' type='text' maxlength='120' style='width:300px; border:1px solid #999999' /></td>");
	pw.println("</tr><tr>");
	pw.println("<td><b>State/Province :</b></td>");
	pw.println("<td><input id='State' name='State' type='text' /></td>");
	pw.println("</tr>");
	pw.println("<tr>");
	pw.println("<td><b>Icecream Name :</b></td>");
	pw.println("<td><input id='iname' name='iname' type='text' value=Cornato /></td>");
	pw.println("</tr>");
	pw.println("<tr>");
	pw.println("<td><b>Price :</b></td>");
	pw.println("<td><input id='Price' name='Price' type='text' value=120/></td>");
	pw.println("</tr>");
	pw.println("</table>");
	pw.println("<input type= 'submit' name='submit' value='Submit' /> <a href='login.html' >Login Page</a>");
	pw.println("<br />");
	pw.println("</form>");
	pw.println("<body>");
	pw.println("</center>");
			}catch(Exception e){
		}
	}
}

