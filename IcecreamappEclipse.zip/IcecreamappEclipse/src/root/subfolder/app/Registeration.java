package root.subfolder.app;
import javax.servlet.*;
import java.io.*;
import java.sql.*;
import java.util.*;

public class  Registeration extends GenericServlet
{
	public void service(ServletRequest req,ServletResponse res)throws IOException{	
		String first_name=req.getParameter("FirstName");
		String last_name=req.getParameter("LastName");
		String email=req.getParameter("FromEmailAddress");
		String uname=req.getParameter("uname");
		String pswd=req.getParameter("pswd");
		String mno=req.getParameter("CellPhone");
		String address=req.getParameter("StreetAddress1");
		String city=req.getParameter("City");
		String state=req.getParameter("State");
		//String country=req.getParameter("Country");
		String iname=req.getParameter("iname");
		String price=req.getParameter("Price");
		PrintWriter pw=res.getWriter();

		try{
				/*Properties p=new Properties();
		FileInputStream fis=new FileInputStream("mysqlDatabase.property");
		p.load(fis);*/
		ServletContext sc=getServletContext();
		String driver=sc.getInitParameter("driver");
		String url=sc.getInitParameter("url");
		String username=sc.getInitParameter("username");
		String password=sc.getInitParameter("password");
			
			Class.forName(driver);
			Connection con=DriverManager.getConnection(url,username,password);
		pw.println("Connected ..");
		PreparedStatement ps=con.prepareStatement("insert into icecreamtable values(?,?,?,?,?,?,?,?,?,?,?)");
			 ps.setString(1,first_name);
		 ps.setString(2,last_name);
		 ps.setString(3,email);
		ps.setString(4,uname);
		 ps.setString(5,pswd);
		long mno1=Long.parseLong(mno);
		 ps.setLong(6,mno1);
		 ps.setString(7,address);
		 ps.setString(8,city);
		 ps.setString(9,state);
		ps.setString(10,iname);
		int price1=Integer.parseInt(price);
		ps.setInt(11,price1);
		 
			ps.executeUpdate();
		
		pw.println("<html>");
				pw.println("<style>");

		pw.println("body{");
		pw.println("background-image:url('back.jpg')}");
		pw.println("</style>");
				pw.println("<body bgcolor='orange'><center>");
				pw.println("<h1> <b> Registered Successfully ...</h1>");
							pw.println("<br><h1> <b> Hello "+first_name+"</h1>");
							pw.println("<br><a href='login.html' >Login Page</a>");
							pw.println("</center></body>");
					pw.println("</html>");
		}catch(Exception e){
			pw.println(e);
			e.printStackTrace();
			pw.println("Username already exist please enter new one ..");
		}

	}
}
