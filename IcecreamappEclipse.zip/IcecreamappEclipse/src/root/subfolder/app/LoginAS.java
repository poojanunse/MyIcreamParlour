package root.subfolder.app;
import javax.servlet.*;
import java.io.*;
import java.sql.*;
import java.util.*;
public class LoginAS extends GenericServlet
{
	public void service(ServletRequest req,ServletResponse res){	
		String uname=req.getParameter("uname");
		String pswd=req.getParameter("pswd");
		try{
			PrintWriter pw=res.getWriter();
				/*Properties p=new Properties();
		FileInputStream fis=new FileInputStream("mysqlDatabase.property");
		p.load(fis);*/
		ServletContext sc=getServletContext();
		String driver=sc.getInitParameter("driver");
		String url=sc.getInitParameter("url");
		String username=sc.getInitParameter("username");
		String password=sc.getInitParameter("password");
			Class.forName(driver);
			Connection con=DriverManager.getConnection(url,username,password);
			pw.println("connected");
			Statement statement=con.createStatement();
			if(uname.equals("admin")&&pswd.equals("admin")){
		ResultSet rs=statement.executeQuery("select * from icecreamtable");
		ResultSetMetaData rsm=rs.getMetaData();
		int count=rsm.getColumnCount();
		pw.println("<html>");
				pw.println("<style>");

		pw.println("body{");
		pw.println("background-image:url('back.jpg')}");
		pw.println("</style>");
				pw.println("<br><h1><center> <b>Welcome "+uname+"</h1></center><br>");
			
pw.println("<table border='2' vspace='200' hspace ='500' >");
pw.println("<tr>");
				for(int i=1;i<=count;i++){
					pw.println("<th>");
					
				pw.print("<h2> <b>  "+rsm.getColumnName(i)+"\t"+"</h2>");
				pw.println("</th>");
					}
					pw.println("</tr>");
		while(rs.next()){
				pw.println("<tr>");
					for(int i=1;i<=count;i++){
						pw.println("<td>");
				pw.print("<h2>    "+rs.getString(i)+"\t"+"</h2>");
				pw.println("</td>");
					}
					pw.println("</tr>");
		}//while
		pw.println("</table>");
					pw.println("<br><center><a href='index.html' >index Page</a></center>");
				pw.println("</center></body>");
					pw.println("</html>");
			}//if
			else{
		pw.println("Username or Password might be wrong ..");
			}
		}/*try*/catch(Exception e){
			
		}
	}//service

}//cls
